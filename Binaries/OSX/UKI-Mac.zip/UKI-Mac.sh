#!/bin/bash 
open ./UKI.app --args -logFile log.txt -portName "/dev/tty.usbserial-A101OCIF" -baudRate 9600